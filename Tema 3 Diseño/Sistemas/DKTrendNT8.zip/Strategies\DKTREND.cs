#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	public class DKTREND : Strategy
	{
		private EMA MLH;
		private EMA MLL;
		private EMA MR;
		private ADXBDinamica ABD;
		
		// Variables internas.
		private double MaxADX = 0;		  // Esta variable nos servirá para almacenar el valor más alto	alcanzado en el ADX en el periodo seleccionado.
		private int OpesAlcistas = 0;     // Nos servirá para almacenar el número de operaciones alcistas realizadas durante la sesión.
		private int OpesBajistas = 0;     // Nos servirá para almacenar el número de operaciones bajistas realizadas durante la sesión.
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "DKTREND";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				MediaLenta		= 100;
				MediaRapida		= 25;
				FinDia			= 2200;
				PeriodoMaxADX	= 500;
				TamañoBanda		= 0.5;
				NTrades			= 1;
				
			}
			else if (State == State.DataLoaded)
			{
				MLH = EMA(High, MediaLenta);
				MLL = EMA(Low, MediaLenta);
				MR = EMA (MediaRapida);
				ABD = ADXBDinamica(PeriodoMaxADX,14,TamañoBanda);
				
				// Personalizamos el color de las medias móviles.
				// El indicador ADXBDinamica se mostrará como se ha configurado por defecto.
				MLH.Plots[0].Brush = Brushes.Green;
				MLL .Plots[0].Brush = Brushes.Red;
				MR.Plots[0].Brush = Brushes.Violet;
				
				// Añadimos los indicadores para que sean mostrados en el gráfico.
				AddChartIndicator(MLH);
				AddChartIndicator(MLL);
				AddChartIndicator(MR);
				AddChartIndicator(ABD);
			}
		}

		protected override void OnBarUpdate()
		{
			// Comprobamos que hay suficientes barras.
			if ( CurrentBar < MediaLenta) return; 
			
			// Ajustamos el formato de la variable FinDia.
			int FD = FinDia * 100;
            
			// Reseteamos el valor de las variables en la primera vela de la sesión.
			if(ToTime(Time[0]) < ToTime(Time[1]))
			{
				OpesAlcistas = 0;
				OpesBajistas = 0;
			}
						
			// Almacenamos el mayor valor alcanzado en el ADX en el periodo seleccionado.
			MaxADX = MAX(ADX(14), PeriodoMaxADX) [0];
			
			// Condiciones para entrar largos.				
			if (CrossAbove(Close, EMA(High, MediaLenta), 1) 
			&& Close[0] > EMA(MediaRapida)[0]
			&& ToTime(Time[0])< FD	
			&& ADX(14)[0] < MaxADX * TamañoBanda
			&& OpesAlcistas < NTrades)
           	{					
				EnterLong(1, "");
				OpesAlcistas ++;
			}
			
			// Condiciones para entrar Cortos.		
			if (CrossBelow(Close, EMA(Low, MediaLenta), 1) 
			&& Close[0] < EMA(MediaRapida)[0]
			&& ToTime(Time[0])< FD				
			&& ADX(14)[0] < MaxADX * TamañoBanda
			&& OpesBajistas < NTrades)			
            {
				EnterShort(1, "");
				OpesBajistas ++;
			}
	
			// Condiciones para cerrar Largos.
            if (CrossBelow(Close, EMA(MediaRapida), 1)|| ToTime(Time[0]) >= FD)
            	ExitLong("", "");
            					
			// Condiciones para cerrar Cortos.
            if (CrossAbove(Close, EMA(MediaRapida), 1) || ToTime(Time[0]) >= FD)
            	ExitShort("", "");
			
			
			// Salida de Largos en el mínimo diario.
			ExitLongStopMarket (CurrentDayOHL().CurrentLow[0], "","");
			
			// Salida de Cortos en máximo diario.
			ExitShortStopMarket (CurrentDayOHL().CurrentHigh[0], "","");			
			

			// Coloreamos el panel de precios cuando el ADX está por debajo de su banda dinámica.
			if (ADX(14)[0] < MaxADX * TamañoBanda) BackBrushAll = Brushes.LightBlue;
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="MediaLenta", Description="Periodo de la Media Móvil Lenta", Order=1, GroupName="Parameters")]
		public int MediaLenta
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="MediaRapida", Description="Periodo de la Media Móvil Rápida", Order=2, GroupName="Parameters")]
		public int MediaRapida
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="FinDia", Description="Horario de Cierre de Posiciones", Order=3, GroupName="Parameters")]
		public int FinDia
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="PeriodoMaxADX", Description="Periodo de cálculo del Máximo del ADX", Order=4, GroupName="Parameters")]
		public int PeriodoMaxADX
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="TamañoBanda", Description="Tamaño de la banda dinámica del ADX", Order=5, GroupName="Parameters")]
		public double TamañoBanda
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="NTrades", Description="Número de operaciones permitidas de cada pata. P.Eje. Un valor de 2 permitirá 4 operaciones en la sesión, 2 de largos y 2 de cortos.", Order=6, GroupName="Parameters")]
		public int NTrades
		{ get; set; }
		#endregion

	}
}
