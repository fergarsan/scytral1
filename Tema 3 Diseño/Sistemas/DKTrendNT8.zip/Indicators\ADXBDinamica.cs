#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class ADXBDinamica : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Enter the description for your new custom Indicator here.";
				Name										= "ADXBDinamica";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				ValorMaxADX					= 300;
				Periodo					= 14;
				TBanda					= 0.5;
				AddPlot(Brushes.Orange, "MaxADX");
				AddPlot(Brushes.Green, "ValorADX");
				AddPlot(Brushes.Violet, "BandaDinamica");
			}
			
		}

		protected override void OnBarUpdate()
		{
			
			if (CurrentBar < ValorMaxADX) return;
			
            MaxADX[0]= (MAX(ADX(Periodo), ValorMaxADX)[0]);
            ValorADX[0] = (ADX(Periodo)[0]);
            BandaDinamica[0]= (MaxADX[0]* TBanda);
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="ValorMaxADX", Order=1, GroupName="Parameters")]
		public int ValorMaxADX
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Periodo", Order=2, GroupName="Parameters")]
		public int Periodo
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0.5, double.MaxValue)]
		[Display(Name="TBanda", Order=3, GroupName="Parameters")]
		public double TBanda
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> MaxADX
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> ValorADX
		{
			get { return Values[1]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> BandaDinamica
		{
			get { return Values[2]; }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private ADXBDinamica[] cacheADXBDinamica;
		public ADXBDinamica ADXBDinamica(int valorMaxADX, int periodo, double tBanda)
		{
			return ADXBDinamica(Input, valorMaxADX, periodo, tBanda);
		}

		public ADXBDinamica ADXBDinamica(ISeries<double> input, int valorMaxADX, int periodo, double tBanda)
		{
			if (cacheADXBDinamica != null)
				for (int idx = 0; idx < cacheADXBDinamica.Length; idx++)
					if (cacheADXBDinamica[idx] != null && cacheADXBDinamica[idx].ValorMaxADX == valorMaxADX && cacheADXBDinamica[idx].Periodo == periodo && cacheADXBDinamica[idx].TBanda == tBanda && cacheADXBDinamica[idx].EqualsInput(input))
						return cacheADXBDinamica[idx];
			return CacheIndicator<ADXBDinamica>(new ADXBDinamica(){ ValorMaxADX = valorMaxADX, Periodo = periodo, TBanda = tBanda }, input, ref cacheADXBDinamica);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.ADXBDinamica ADXBDinamica(int valorMaxADX, int periodo, double tBanda)
		{
			return indicator.ADXBDinamica(Input, valorMaxADX, periodo, tBanda);
		}

		public Indicators.ADXBDinamica ADXBDinamica(ISeries<double> input , int valorMaxADX, int periodo, double tBanda)
		{
			return indicator.ADXBDinamica(input, valorMaxADX, periodo, tBanda);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.ADXBDinamica ADXBDinamica(int valorMaxADX, int periodo, double tBanda)
		{
			return indicator.ADXBDinamica(Input, valorMaxADX, periodo, tBanda);
		}

		public Indicators.ADXBDinamica ADXBDinamica(ISeries<double> input , int valorMaxADX, int periodo, double tBanda)
		{
			return indicator.ADXBDinamica(input, valorMaxADX, periodo, tBanda);
		}
	}
}

#endregion
